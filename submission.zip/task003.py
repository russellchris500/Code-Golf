p=lambda g:[[c*2for c in r]for r in (g[:(g[1]!=g[4])+3])*3][:9]
