def p(input):
    return